package com.cg.employee.beans;

public class Employee {
	private int employeeId;
	float totalSalary,basicSalary;
	public float getTotalSalary() {
		return totalSalary;
	}
	public void setTotalSalary(float totalSalary) {
		this.totalSalary = totalSalary;
	}
	private String firstName,lastName;
	public Employee(){
		super();
	}
	
	public Employee(int employeeId, String firstName, String lastName) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public Employee(int employeeId,float basicSalary,String firstName,String lastName){
		super();
		this.employeeId = employeeId;
		this.basicSalary = basicSalary;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public float getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void calculateSalary(){
		this.totalSalary=basicSalary;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", totalSalary=" + totalSalary + ", basicSalary=" + basicSalary
				+ ", firstName=" + firstName + ", lastName=" + lastName + "]";
	}
	
}
