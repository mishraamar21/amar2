package com.cg.employee.beans;
public class CEemployee extends Employee{
	private float hrs,variablePay;

	public CEemployee() {
		super();
	}
	public CEemployee(int employeeId,String firstName,String lastName,float hrs){
		super( employeeId,  firstName,lastName);
		this.hrs=hrs;
}
	public CEemployee(int employeeId,String firstName,String lastName,float hrs, float variablePay) {
		super(employeeId,firstName,lastName);
		this.hrs = hrs;
		this.variablePay = variablePay;
	}
	
	public float getHrs() {
		return hrs;
	}
	public void setHrs(float hrs) {
		this.hrs = hrs;
	}
	public float getVariablePay() {
		return variablePay;
	}
	public void setVariablePay(float variablePay) {
		this.variablePay = variablePay;
	}
	public void calculateSalary(){
		this.variablePay=hrs*2000;
		//this.setT(this.basicSalary+variablePay);
		
}
	
	@Override
	public String toString() {
		return super.toString()+ "hrs=" + hrs + ", variablePay=" + variablePay + "]";
	}


	

}
