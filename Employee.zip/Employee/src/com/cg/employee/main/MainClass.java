package com.cg.employee.main;

import com.cg.employee.beans.CEemployee;
import com.cg.employee.beans.Employee;
import com.cg.employee.beans.PEmployee;

public class MainClass {

	public static void main(String[] args) {
       Employee employee = new Employee(222,3000f,"AVANI","REDDY");
       employee.calculateSalary();
       System.out.println(employee.toString());
       
       PEmployee pemployee = new PEmployee(222,40000f,"AVI","REDDY");
   		pemployee.calculateSalary();
   		System.out.println(pemployee.toString());
   		
   		CEemployee ceemployee = new CEemployee(111, "avani", "reddy", 2);
   		ceemployee.calculateSalary();
   		System.out.println(ceemployee.toString());
	}
	
	
	
}
