package com.cg.Banking.main;
import com.cg.Banking.beans.Account;
import com.cg.Banking.beans.Address;
import com.cg.Banking.beans.Customer;
import com.cg.Banking.beans.Transaction;
public class MainClass {

	public static void main(String[] args) {	
		Customer[] customer = new Customer[2];
		Account[] accounts = new Account[2];
		Account[] accounts1 = new Account[2];
		Transaction[] transaction = new Transaction[2];
		 transaction[0] = new Transaction(222,6666,"HHHH","CREDIT","PUNE","ONLINE","SUCCESS");
		 transaction[1] = new Transaction(222,6666,"HHHH","CREDIT","PUNE","ONLINE","SUCCESS");
		 customer[0] = new Customer(2222,3456,678905,"AVANI","REDDY","SAVANIREDDY@GMAIL.COM","HGFD","11/7/1995",accounts,new Address(2345,"TELANGANA","HYDERABAD","INDIA"),new Address(2345,"TEL","HYD","IND"));
		 customer[1] = new Customer(2222,3456,678905,"AVANI","REDDY","SAVANIREDDY@GMAIL.COM","HGFD","12/7/1995",accounts1,new Address(2345,"TELANGANA","HYDERABAD","INDIA"),new Address(2345,"TEL","HYD","IND"));
		 accounts[0] = new Account(3333,50000,"SAVING",transaction);
		 accounts1[0] = new Account(345,7000,"CURRENT",transaction);
		 
		System.out.println(customer[0].getAccounts()[0].getAccountNo()+" "+customer[1].getAccounts()[0].getAccountNo());
 }
}
