package com.cg.Banking.beans;

public class Address {
	private int pinCode;
	private String state,city,country;
	public Address(int pinCode, String state, String city, String country) {
		super();
		this.pinCode = pinCode;
		this.state = state;
		this.city = city;
		this.country = country;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}

}