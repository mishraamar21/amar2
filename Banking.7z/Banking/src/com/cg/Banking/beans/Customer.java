package com.cg.Banking.beans;

public class Customer {
	private int customerId,andharNo,mobileNo;
	private String firstname,lastname,emailId,pancardNo,dateOfBirth;
	private Account[] accounts;
	private Address loacladdress,homeaddress;
	public Customer(int customerId, int andharNo, int mobileNo, String firstname, String lastname, String emailId,
			String pancardNo, String dateOfBirth, Account[] accounts, Address loacladdress, Address homeaddress) {
		super();
		this.customerId = customerId;
		this.andharNo = andharNo;
		this.mobileNo = mobileNo;
		this.firstname = firstname;
		this.lastname = lastname;
		this.emailId = emailId;
		this.pancardNo = pancardNo;
		this.dateOfBirth = dateOfBirth;
		this.accounts = accounts;
		this.loacladdress = loacladdress;
		this.homeaddress = homeaddress;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getAndharNo() {
		return andharNo;
	}
	public void setAndharNo(int andharNo) {
		this.andharNo = andharNo;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Account[] getAccounts() {
		return accounts;
	}
	public void setAccounts(Account[] accounts) {
		this.accounts = accounts;
	}
	public Address getLoacladdress() {
		return loacladdress;
	}
	public void setLoacladdress(Address loacladdress) {
		this.loacladdress = loacladdress;
	}
	public Address getHomeaddress() {
		return homeaddress;
	}
	public void setHomeaddress(Address homeaddress) {
		this.homeaddress = homeaddress;
	}
}
	
	