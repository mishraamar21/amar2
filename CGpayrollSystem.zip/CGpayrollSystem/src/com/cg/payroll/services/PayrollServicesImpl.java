package com.cg.payroll.services;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.*;
public class PayrollServicesImpl {
	
	private PayrollDAOServicesImpl daoServices;
	
	public PayrollServicesImpl(){
		daoServices = new PayrollDAOServicesImpl();
	}
	
	public int acceptAssociateDetails(String firstname,String lastname,String emailId,String department,String designation,String panCard,
			    float yearlyInvestmentUnder80C,float basicSalary,float epf,float companyPf,int accountNumber,String bankName,String ifscCode){
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C,firstname,lastname,department,designation,panCard,emailId, new Salary(basicSalary, epf, companyPf),new BankDetails(accountNumber, bankName, ifscCode)));
	}
	public float calculateNetSalary(int associateId){
		 float personalAllowance,  conveyenceAllowance,  otherAllowance,  companypf, hra,  monthlytax,  epf,  annualSalary,  yearlyInvestmentUnder80C,  basicSalary,tax,i,netSalary,j;
		Associate associate = this.getAssociateDetails(associateId);
		if(associate!=null){
			basicSalary=associate.getSalary().getBasicSalary();
			associate.getSalary().setConveyenceAllowance(0.1f*associate.getSalary().getBasicSalary());
			associate.getSalary().setPersonalAllowance(0.3f*associate.getSalary().getBasicSalary());associate.getSalary().setOtherAllowance(0.1f*associate.getSalary().getBasicSalary());
			associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGratuity(0.05f*associate.getSalary().getBasicSalary());
			epf=associate.getSalary().getEpf();
			companypf=associate.getSalary().getCompanyPf();
			float grossSalary = basicSalary+associate.getSalary().getPersonalAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getCompanyPf()+associate.getSalary().getHra();
			float annualSalary1 = grossSalary*12;
			if((associate.getYearlyInvestmentUnder80C()+12*(companypf+epf)>=150000)){
			 j=150000;
			}
			else 
				j=associate.getYearlyInvestmentUnder80C()+12*(companypf+epf);			
			if(annualSalary1<250000){
				associate.getSalary().setMonthlyTax(0);
				associate.getSalary().setNetSalary((grossSalary-epf-companypf));
				return (grossSalary-epf-companypf);
			}
			else if(annualSalary1>=250000&&annualSalary1<500000){
				i=(annualSalary1-250000-j);
				if(i<0)
					tax=0;
				tax=(float) ((0.1*i)/12);
				associate.getSalary().setMonthlyTax(tax);
				associate.getSalary().setNetSalary((grossSalary-epf-companypf));
				return (grossSalary-epf-companypf-tax);
			}
			else if(annualSalary1>=500000&&annualSalary1<1000000){
				i=(float) ((250000-j)*0.1);
				tax=(float) ((((annualSalary1-500000)*0.2)+i)/12);
				associate.getSalary().setMonthlyTax(tax);
				associate.getSalary().setNetSalary((grossSalary-epf-companypf));
				return (grossSalary-epf-companypf-tax);
			}
			else if(annualSalary1>=1000000){
				i=(float) ((250000-j)*0.1);
				tax=(float) ((i+100000+((annualSalary1-1000000)*0.3))/12);
				associate.getSalary().setMonthlyTax(tax);
				associate.getSalary().setNetSalary((grossSalary-epf-companypf));
				return (grossSalary-epf-companypf-tax);
			}
		
			
					
					
				
			}
			

				
				
			
			
			
			
	//	}
		return 0;
	}
	public Associate getAssociateDetails(int associateId){
		return daoServices.getAssociate(associateId);
	}
	public Associate[] getAllAssociateDetails(){
		return null;
	}

}
